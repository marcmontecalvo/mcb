# @homenet/ui 0.3.0

HomeNet's supported React component path, with shadcn-style composition over Radix Dialog and Tailwind CSS 4. The host supplies routing, sign-in, authorization and data. This package executes no connector markup, manifest text or memory content. It is not an add-on execution boundary.

Build with `pnpm --filter @homenet/ui build`; distribute with `pnpm --filter @homenet/ui pack`. Install the resulting package in a second app with React 18.3 or 19. Import components from `@homenet/ui` and CSS from `@homenet/ui/styles.css`. This compiled stylesheet includes tokens and utilities and requires no consumer Tailwind build. It does not include a global reset. Non-React apps may import `@homenet/ui/tokens.css` alone.

Set `data-theme="fieldstone|blossom|evergreen|dusk"` on the host container. Tokens preserve the established names (`--bg`, `--surface`, `--ink`, `--muted`, `--line`, `--brand`, `--brand-ink` and semantic status colors). Import `@homenet/ui/fonts.css` to serve the bundled, OFL-licensed Figtree fonts locally, or keep the host’s existing Figtree font routes. Dialog inherits a document theme by default; pass `theme` when the theme is scoped below body.

```tsx
import { AppFrame, PageHeader, Card, Button } from '@homenet/ui';
import '@homenet/ui/styles.css';

<AppFrame data-theme="fieldstone" account="Signed in as Marc" navigation={hostNavigation}>
  <PageHeader title="Household" eyebrow="HomeNet" />
  <Card title="Connections"><Button>View connections</Button></Card>
</AppFrame>
```

## Components

All components accept `className`. Native attributes pass through to their semantic element; Card/PageHeader/ListItem replace the native string `title` attribute with React content.

| Component | Props and behavior |
| --- | --- |
| Button | Native button props/ref; `variant` primary, secondary (default), ghost, danger or destructive alias; `loading` disables and sets `aria-busy`. Default type is button. Keep its visible label while loading. |
| Card | Section with optional `title` (h2), `description`, children. Use on content pages beneath one h1. |
| Badge | Text span; `tone` attention, working, ready or quiet (default). Status must have a text label, not only color. |
| Alert | Required `title`, children, tone attention by default. Default role status; use role alert for errors caused by an interaction. |
| EmptyState | Required `title`, explanatory children, optional `action`. Empty and unavailable are different states; use Alert for unavailable data. |
| Field | Native input props/ref; required `label`; optional description/error. Generates matching IDs and associates help/error text. Error sets aria-invalid. Supply stable IDs when using HTML form labels outside the component. |
| Select / Textarea | Native control props/ref plus required label and optional description/error; same associations as Field. |
| Checkbox / Radio | Native choice props/ref plus required label and optional description/error. |
| FieldGroup | Native fieldset props plus required legend. |
| Navigation / NavLink | Accessible nav label; host-owned hrefs; active maps to aria-current=page. |
| Table | Required accessible label; native table props and keyboard-scrollable wrapper. |
| ListItem | Semantic li; required `title`, optional description/leading/trailing/children. Place inside ul or ol. Long content wraps. |
| Dialog | Required trigger React element and title; optional description/children/open/onOpenChange/theme. Radix owns focus containment, Escape, accessible names, background inertness and focus restoration. Hydrate interactive React components in the host. Never put active controls in a disabled trigger. |
| AppFrame | Neutral page assembly: brand (defaults HomeNet), account, navigation and footer slots plus children. Host owns all URLs and attribution. It includes main by default; use `contentAs="div"` when the host already supplies the main landmark. |
| PageHeader | Required title (h1), optional titleId/eyebrow/description/actions. |
| Stack / Grid | Responsive layout containers with native div props. Stack has 24px vertical gaps; Grid fits columns down to 280px or available width. |

No component fetches or changes data. Loading, unavailable, stale and empty states come from the host's authorized projection. Server rendering preserves plain text escaping. Any write button still needs the host's existing authorized human-write contract.

## Maintenance

Radix is the only interactive primitive family. HomeNet owns variants and package APIs; assess upstream shadcn and Radix changes before updating, then run package typecheck/build, consumer builds, keyboard focus/escape tests and four-theme visual/accessibility/reflow checks. Source patterns: [shadcn Dialog](https://ui.shadcn.com/docs/components/radix/dialog), [Radix Dialog](https://www.radix-ui.com/primitives/docs/components/dialog), [Tailwind theme variables](https://tailwindcss.com/docs/theme). Version dependencies are pinned; peer ranges deliberately support both current consumer React majors.

## Isolated browser fixture

Run `pnpm --filter @homenet/ui test:browser` after the package build and Chromium installation. The bundled React fixture is outside the private web app and uses no household data or session. It checks all four themes with axe WCAG A/AA rules, real Dialog activation/Tab containment/Escape/focus restoration, 320px and 640px reflow, and 200% CSS zoom. Committed screenshots live in `tests/baselines/`; failures go to HomeNet’s `test-results/ui-package/`. This supplements host and connector boundary tests rather than proving authorization itself.

## Shared presentation contract (0.2.0)

CSS declares `theme`, `base`, `components`, `utilities` in that order. Component defaults live in `components`; a consumer Tailwind build or compiled utility can override them. Only utilities found in package sources/fixtures are shipped: arbitrary consumer class names require a consumer Tailwind build. No global reset is installed. AppFrame includes its own box sizing. Put broad host element defaults (for example `a { color: ... }`) in `@layer base` so they do not override every shared component.

Typography uses Figtree, 16px body text and a 30px/1.15 page title. Cards use 16px corners; form controls and navigation items use 12px corners. Navigation has a consistent active-page treatment. Hosts retain routing, responsive placement and authorization.

Select and Textarea accept native attributes/ref plus required label, description and error, with the same accessible associations as Field. Checkbox and Radio accept native checked/defaultChecked/name/value/ref plus required label and description/error. Use FieldGroup (required legend) to group related choices. Native keyboard behavior and form submission are preserved. Navigation accepts an accessible label and host-owned links; NavLink adds active/aria-current. Table requires a label and provides a keyboard-scrollable region around a semantic table. Native server-rendered forms may opt into equivalent control styling with `hn-form-scope`; custom grids and domain behavior stay host-owned.

Screenshot checks compare committed synthetic-data baselines; missing baselines fail. Update explicitly after visual inspection with `pnpm test:ui:update`. Baselines cover desktop and 320px controls/navigation in four themes plus Dialog, and representative HomeNet pages. Calendar and FoodFlow keep their own application baselines and update commands. Never record real household data as a baseline.

## Space-glass (0.3.0)

Opt in with `data-theme="space-glass"` on an application container. Import
`@homenet/ui/styles.css` and `@homenet/ui/fonts.css`; Manrope and JetBrains
Mono are served locally. For a Dialog whose theme is scoped below the document,
pass `theme="space-glass"` so its portal receives the same tokens. Existing
four themes remain available. The source export's tokens are exposed as
`--sg-*`; `hn-sg-figure`, `hn-sg-detail-title`, `hn-sg-section-title`,
`hn-sg-screen-title`, `hn-sg-panel-title`, `hn-sg-body`, `hn-sg-body-strong`,
`hn-sg-body-sm`, `hn-sg-sub`, `hn-sg-tag`, `hn-sg-nav-label`, `hn-sg-code` and
`hn-sg-command` provide the complete type scale. The `hn-sg-*` classes in
`styles.css` also expose the original glass, tile, action, status, meter, chat
and motion primitives inside the theme; these are styling primitives, not
interactive React components. Consumers must supply semantic markup, labels,
keyboard behavior and state. `hn-sg-stars` is optional decoration. See the HomeNet repository’s `planning/active/space-glass-token-coverage.md` for token usage and reserved values.

The source export takes precedence over the earlier mockup: primary buttons
are light (no orange primary button), glass uses an inset edge, and ordinary
inner tiles are borderless. HomeNet deliberately adds a disabled-button opacity
state, which the source export does not specify. The original exact values are retained. The design
export identifies `text-faint` as below 4.5:1 for small text, and the off switch
and field edge as below 3:1; labels do not by themselves remedy that contrast
failure. Assess these before production use. The theme does not claim WCAG AA
conformance. `pnpm test:ui` runs the source comparison and writes temporary screenshots;
set `SPACE_GLASS_EVIDENCE=1` to refresh the repository evidence explicitly.
Space-glass is local work; consumers pinned to 0.2.0 continue to
use that release until separately upgraded and verified.
